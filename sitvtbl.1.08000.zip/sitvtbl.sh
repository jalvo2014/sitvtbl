#!/bin/sh
# Set CANDLEHOME before starting or alter the next line to set installation directory for TEPS
if [ "$CANDLEHOME" = "" ]; then export CANDLEHOME=/opt/IBM/ITM; fi
${CANDLEHOME}/bin/itmcmd execute cq 'KfwSQLClient /e "SELECT NODE,NODELIST FROM O4SRV.TNODELST"' >QA1CNODL.DB.LST
${CANDLEHOME}/bin/itmcmd execute cq 'KfwSQLClient /e "SELECT NODE,O4ONLINE,PRODUCT,RESERVED FROM O4SRV.TNODESAV"' >QA1DNSAV.DB.LST
${CANDLEHOME}/bin/itmcmd execute cq 'KfwSQLClient /e "SELECT SITNAME,AUTOSTART FROM O4SRV.TSITDESC"' >QA1CSITF.DB.LST
